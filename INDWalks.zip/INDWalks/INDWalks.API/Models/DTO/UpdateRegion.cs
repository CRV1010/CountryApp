﻿using System.ComponentModel.DataAnnotations;

namespace INDWalks.API.Models.DTO
{
    public class UpdateRegion
    {
        [Required]
        [MinLength(2, ErrorMessage = "Code Should be minimum of 2 letters")]
        [MaxLength(3, ErrorMessage = "Code Should be maximum of 3 letters")]
        public string Code { get; set; }
        [Required]
        [MaxLength(30, ErrorMessage = "Name can be of Max 30 letters only")]
        public string Name { get; set; }
        public string? RegionImageUrl { get; set; }
    }
}
