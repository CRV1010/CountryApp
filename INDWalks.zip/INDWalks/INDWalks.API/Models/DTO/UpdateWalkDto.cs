﻿using System.ComponentModel.DataAnnotations;

namespace INDWalks.API.Models.DTO
{
    public class UpdateWalkDto
    {
        [Required]
        [MaxLength(30, ErrorMessage = "Name can be of max 30 letters")]
        public string Name { get; set; }

        [Required]
        [MaxLength(200, ErrorMessage = "Description can be of max 200 letters")]
        public string Description { get; set; }

        [Required]
        [Range(1, 50)]
        public double LengthInKm { get; set; }
        public string? WalkImageUrl { get; set; }
        [Required]
        public Guid DifficultyId { get; set; }
        [Required]
        public Guid RegionId { get; set; }
    }
}
