﻿using AutoMapper;
using INDWalks.API.Models.Domain;
using INDWalks.API.Models.DTO;

namespace INDWalks.API.Mappings
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Region, RegionDto>().ReverseMap();
            CreateMap<Region, AddRegionDto>().ReverseMap();
            CreateMap<Region, UpdateRegion>().ReverseMap();
            CreateMap<Walk,AddWalkDto>().ReverseMap();
            CreateMap<Walk,WalkDto>().ReverseMap();
            CreateMap<DifficultyDto,Difficulty>().ReverseMap();
            CreateMap<UpdateWalkDto, Walk>().ReverseMap();
            CreateMap<ImageUploadRequestDto, Image>().ReverseMap();
        }
    }
}
