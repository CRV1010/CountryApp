﻿using INDWalks.API.Data;
using INDWalks.API.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace INDWalks.API.Repositories
{
    public class SqlRegionRepository : IRegionRepository
    {
        private readonly INDWalksDbContext dbContext;

        public SqlRegionRepository(INDWalksDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Region> CreateAsync(Region region)
        {
            await dbContext.Region.AddAsync(region);
            await dbContext.SaveChangesAsync();
            return region;
        }

        public async Task<Region?> DeleteAsync(Guid id)
        {
            var regionDomain = await dbContext.Region.FirstOrDefaultAsync(x=> x.Id == id);
            if (regionDomain == null)
            {
                return null;
            }
            dbContext.Region.Remove(regionDomain);
            await dbContext.SaveChangesAsync();
            return regionDomain;
        }

        public async Task<List<Region>> GetAllAsync()
        {
            return await dbContext.Region.ToListAsync();
        }

        public async Task<Region?> GetByIdAsync(Guid id)
        {
            var regionDomain = await dbContext.Region.FirstOrDefaultAsync(x=>x.Id == id);
            if(regionDomain == null)
            {
                return null;
            }
            return regionDomain;
        }

        public async Task<Region?> UpdateAsync(Guid id, Region region)
        {
            var regionDomain = await dbContext.Region.FirstOrDefaultAsync(x => x.Id == id);
            if (regionDomain == null)
            {
                return null;
            }
            regionDomain.Code = region.Code;
            regionDomain.Name = region.Name;
            regionDomain.RegionImageUrl = region.RegionImageUrl;

            await dbContext.SaveChangesAsync();
            return regionDomain;
        }
    }
}
