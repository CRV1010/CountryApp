﻿using INDWalks.API.Data;
using INDWalks.API.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace INDWalks.API.Repositories
{
    public class SqlWalkRepository : IWalkRepository
    {
        private readonly INDWalksDbContext dbContext;

        public SqlWalkRepository(INDWalksDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<Walk> CreateAsync(Walk walk)
        {
            await dbContext.Walk.AddAsync(walk);
            await dbContext.SaveChangesAsync();
            return walk;
        }

        public async Task<Walk?> DeleteAsync(Guid id)
        {
            var WalkDomain = await dbContext.Walk.FirstOrDefaultAsync(x => x.Id == id);
            if(WalkDomain == null )
            {
                return null;
            }
            dbContext.Walk.Remove(WalkDomain);
            await dbContext.SaveChangesAsync();
            return WalkDomain;
        }

        public async Task<List<Walk>> GetAllAsync(string? filterOn = null, string? filterQuery = null,
                    string? sortBy=null,bool isAscending=true,
                    int pageNumber = 1, int pageSize = 100)
        {
            //var walkDomain = await dbContext.Walk.Include("Region").Include("Difficulty").ToListAsync();
            // walks is of IQueryable type so we can apply sorting and filtering on it
            var walks = dbContext.Walk.Include("Region").Include("Difficulty").AsQueryable();

            // filtering
            if(string.IsNullOrWhiteSpace(filterOn)==false && string.IsNullOrWhiteSpace(filterQuery)==false)
            {
                if (filterOn.Equals("Name", StringComparison.OrdinalIgnoreCase))
                {
                    walks = walks.Where(x => x.Name.Contains(filterQuery));
                }
                if (filterOn.Equals("LengthInKm", StringComparison.OrdinalIgnoreCase))
                {
                    walks = walks.Where(x => x.LengthInKm < double.Parse(filterQuery));
                }
            }
            // sorting
            if(string.IsNullOrEmpty(sortBy) == false)
            {
                if (sortBy.Equals("Name", StringComparison.OrdinalIgnoreCase))
                {
                    walks = isAscending ? walks.OrderBy(x => x.Name) : walks.OrderByDescending(x => x.Name);
                }
                else if (sortBy.Equals("Length", StringComparison.OrdinalIgnoreCase))
                {
                    walks = isAscending ? walks.OrderBy(x=>x.LengthInKm):walks.OrderByDescending(x=>x.LengthInKm);    
                }
            }

            //Pagination
            var skipPage = (pageNumber - 1) * pageSize;

            return await walks.Skip(skipPage).Take(pageSize).ToListAsync();
        }

        public async Task<Walk?> GetByIdAsync(Guid id)
        {
            var WalkDomain = await dbContext.Walk.Include("Region").Include("Difficulty").FirstOrDefaultAsync(x=>x.Id == id);
            return WalkDomain;
        }

        public async Task<Walk?> UpdateAsync(Guid id, Walk walk)
        {
            var WalkDomain = await dbContext.Walk.FirstOrDefaultAsync(x=>x.Id == id);
            if (WalkDomain == null)
            {
                return null;
            }

            WalkDomain.Name = walk.Name;
            WalkDomain.LengthInKm = walk.LengthInKm;
            WalkDomain.WalkImageUrl = walk.WalkImageUrl;
            WalkDomain.Description = walk.Description;
            WalkDomain.RegionId = walk.RegionId;
            WalkDomain.DifficultyId = walk.DifficultyId;

            await dbContext.SaveChangesAsync();
            return WalkDomain;
        }
    }
}
