﻿using AutoMapper;
using INDWalks.API.CustomActionFilter;
using INDWalks.API.Data;
using INDWalks.API.Models.Domain;
using INDWalks.API.Models.DTO;
using INDWalks.API.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace INDWalks.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class RegionController : ControllerBase
    {
        //private readonly INDWalksDbContext dbContext;
        private readonly IRegionRepository regionRepository;
        private readonly IMapper mapper;
        private readonly ILogger<RegionController> logger;

        public RegionController(IRegionRepository regionRepository,IMapper mapper,
            ILogger<RegionController> logger)
        {
            //this.dbContext = dbContext;
            this.regionRepository = regionRepository;
            this.mapper = mapper;
            this.logger = logger;
        }

        [HttpGet]
        //[Authorize(Roles ="Reader,Writer")]
        public async Task<IActionResult> GetAll()
        {
            logger.LogWarning("Fetching All Regions");
            //var regions = await dbContext.Region.ToListAsync();
            var regions = await regionRepository.GetAllAsync();
            //var regionsDto = new List<RegionDto>();
            //foreach (var region in regions)
            //{
            //    regionsDto.Add(new RegionDto() {
            //        Id = region.Id,
            //        Code = region.Code,
            //        Name = region.Name,
            //        RegionImageUrl = region.RegionImageUrl
            //    });

            //}
            logger.LogError("Finished fetching");
            var regionsDto = mapper.Map<List<RegionDto>>(regions);

            return Ok(regionsDto);
        }

        [HttpGet]
        [Route("{id:Guid}")]
        //[Authorize(Roles = "Reader")]
        public async Task<IActionResult> GetById([FromRoute] Guid id)
        {
            //var regionDomain = await dbContext.Region.FirstOrDefaultAsync(x => x.Id == id);
            var regionDomain = await regionRepository.GetByIdAsync(id);
            if (regionDomain == null)
            {
                return NotFound();
            }

            //var regionsDto = new RegionDto
            //{
            //    Id = regionDomain.Id,
            //    Code = regionDomain.Code,
            //    Name = regionDomain.Name,
            //    RegionImageUrl = regionDomain.RegionImageUrl
            //};

            var regionsDto = mapper.Map<RegionDto>(regionDomain);

            return Ok(regionsDto);
        }

        [HttpPost]
        //[Authorize(Roles = "Writer")]
        public async Task<IActionResult> Create([FromBody] AddRegionDto addRegionDto)
        {
            if (ModelState.IsValid)
            {
                //var regionDomain = new Region
                //{
                //    Code = addRegionDto.Code,
                //    Name = addRegionDto.Name,
                //    RegionImageUrl = addRegionDto.RegionImageUrl
                //};

                var regionDomain = mapper.Map<Region>(addRegionDto);

                //await dbContext.Region.AddAsync(regionDomain);
                //await dbContext.SaveChangesAsync();

                regionDomain = await regionRepository.CreateAsync(regionDomain);

                var regionDto = mapper.Map<RegionDto>(regionDomain);
                //var regionDto = new RegionDto
                //{
                //    Id = regionDomain.Id,
                //    Code = regionDomain.Code,
                //    Name = regionDomain.Name,
                //    RegionImageUrl = regionDomain.RegionImageUrl
                //};

                return CreatedAtAction(nameof(GetById), new { id = regionDto.Id }, regionDto);

            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [HttpPut]
        [Route("{id:Guid}")]
        [ValidateModel]
        //[Authorize(Roles = "Writer")]
        public async Task<IActionResult> Update([FromRoute] Guid id, [FromBody] UpdateRegion updateRegion) {
                //var regionDomain = await dbContext.Region.FirstOrDefaultAsync(x=> x.Id == id);
                //var regionDomain = new Region
                //{
                //    Code = updateRegion.Code,
                //    Name = updateRegion.Name,
                //    RegionImageUrl = updateRegion.RegionImageUrl
                //};
                var regionDomain = mapper.Map<Region>(updateRegion);
                regionDomain = await regionRepository.UpdateAsync(id, regionDomain);

                if (regionDomain == null)
                {
                    return NotFound();
                }

                //regionDomain.Code = updateRegion.Code;
                //regionDomain.Name = updateRegion.Name;
                //regionDomain.RegionImageUrl = updateRegion.RegionImageUrl;

                //await dbContext.SaveChangesAsync();
                //var regionDto = new RegionDto
                //{
                //    Id = regionDomain.Id,
                //    Code = regionDomain.Code,
                //    Name = regionDomain.Name,
                //    RegionImageUrl = regionDomain.RegionImageUrl
                //};

                var regionDto = mapper.Map<RegionDto>(regionDomain);
                return Ok(regionDto);
        }

        [HttpDelete]
        [Route("{id:Guid}")]
        //[Authorize(Roles = "Writer")]
        public async Task<IActionResult> Delete([FromRoute] Guid id)
        {
            //var regionDomain = await dbContext.Region.FirstOrDefaultAsync(x=>x.Id== id);
            var regionDomain = await regionRepository.DeleteAsync(id);
            if(regionDomain == null)
            {
                return NotFound();
            }
            //dbContext.Region.Remove(regionDomain);
            //await dbContext.SaveChangesAsync();
            // optional return the deleted region
            //var regionDto = new RegionDto
            //{
            //    Id = regionDomain.Id,
            //    Code = regionDomain.Code,
            //    Name = regionDomain.Name,
            //    RegionImageUrl = regionDomain.RegionImageUrl
            //};
            var regionDto = mapper.Map<RegionDto>(regionDomain);
            return Ok(regionDto);
        }

    }
}
