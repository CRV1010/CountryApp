﻿using INDWalks.API.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace INDWalks.API.Data
{

    public class INDWalksDbContext:DbContext
    {
        public INDWalksDbContext(DbContextOptions<INDWalksDbContext> dbContextOptions):base(dbContextOptions)
        {
            
        }
        public DbSet<Difficulty> Difficulty { get; set; }
        public DbSet<Region> Region { get; set; }
        public DbSet<Walk> Walk { get; set; }

        public DbSet<Image> Images { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed data for difficulty
            // Easy , Medium , Hard

            var difficulties = new List<Difficulty>() { 
                new Difficulty()
                {
                    Id = Guid.Parse("3119d76a-f393-4168-a4f9-1283a28d9b5d"),
                    Name = "Easy"
                },
                new Difficulty()
                {
                    Id = Guid.Parse("76a41767-d0b1-4372-99c8-b99ff82dc8ac"),
                    Name = "Medium"
                },
                 new Difficulty()
                {
                    Id = Guid.Parse("09c26811-f1a1-4d7f-9e30-123803d3b025"),
                    Name = "Hard"
                }
            };
            // Seed difficulties into database table Difficulty
            modelBuilder.Entity<Difficulty>().HasData(difficulties);

            // Seed Data for regions
            var regions = new List<Region>()
            {
                new Region(){
                    Id=Guid.Parse("ab60441f-f498-4275-98f7-ddef36602ef0"),
                    Code = "GJ",
                    Name = "Gujarat",
                    RegionImageUrl = "1.jpg"
                },
                 new Region(){
                    Id=Guid.Parse("01e7e480-f72f-490e-b713-a1c7fe5046d5"),
                    Code = "RJ",
                    Name = "Rajasthan",
                    RegionImageUrl = "2.jpg"
                },
                  new Region(){
                    Id=Guid.Parse("043f9a7c-bf32-4b9b-85d0-da60a200db4f"),
                    Code = "WB",
                    Name = "West Bengal",
                    RegionImageUrl = "3.jpg"
                }
            };

            modelBuilder.Entity<Region>().HasData(regions);

        }

    }
}
