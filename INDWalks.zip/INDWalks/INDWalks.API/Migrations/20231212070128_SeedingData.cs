﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace INDWalks.API.Migrations
{
    /// <inheritdoc />
    public partial class SeedingData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Difficulty",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { new Guid("09c26811-f1a1-4d7f-9e30-123803d3b025"), "Hard" },
                    { new Guid("3119d76a-f393-4168-a4f9-1283a28d9b5d"), "Easy" },
                    { new Guid("76a41767-d0b1-4372-99c8-b99ff82dc8ac"), "Medium" }
                });

            migrationBuilder.InsertData(
                table: "Region",
                columns: new[] { "Id", "Code", "Name", "RegionImageUrl" },
                values: new object[,]
                {
                    { new Guid("01e7e480-f72f-490e-b713-a1c7fe5046d5"), "RJ", "Rajasthan", "2.jpg" },
                    { new Guid("043f9a7c-bf32-4b9b-85d0-da60a200db4f"), "WB", "West Bengal", "3.jpg" },
                    { new Guid("ab60441f-f498-4275-98f7-ddef36602ef0"), "GJ", "Gujarat", "1.jpg" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Difficulty",
                keyColumn: "Id",
                keyValue: new Guid("09c26811-f1a1-4d7f-9e30-123803d3b025"));

            migrationBuilder.DeleteData(
                table: "Difficulty",
                keyColumn: "Id",
                keyValue: new Guid("3119d76a-f393-4168-a4f9-1283a28d9b5d"));

            migrationBuilder.DeleteData(
                table: "Difficulty",
                keyColumn: "Id",
                keyValue: new Guid("76a41767-d0b1-4372-99c8-b99ff82dc8ac"));

            migrationBuilder.DeleteData(
                table: "Region",
                keyColumn: "Id",
                keyValue: new Guid("01e7e480-f72f-490e-b713-a1c7fe5046d5"));

            migrationBuilder.DeleteData(
                table: "Region",
                keyColumn: "Id",
                keyValue: new Guid("043f9a7c-bf32-4b9b-85d0-da60a200db4f"));

            migrationBuilder.DeleteData(
                table: "Region",
                keyColumn: "Id",
                keyValue: new Guid("ab60441f-f498-4275-98f7-ddef36602ef0"));
        }
    }
}
