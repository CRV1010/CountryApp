﻿using HR.LeaveManagement.Domain;

namespace HR.LeaveManagement.Application.Contracts.Persistence
{
    public interface ILeaveAllocationRepository : IGenericRepository<LeaveAllocation>
    {
        Task<LeaveAllocation> GetLeaveAllocationWithDetails(int id);
        Task<List<LeaveAllocation>> GetLeaveAllocationWithDetails();
        Task<List<LeaveAllocation>> GetLeaveAllocationWithDetails(string userId);
        Task<bool> AllocaitonExist(string userId,int leaveTypeId,int period);

        Task AddAllocation(List<LeaveAllocation> allocation);
        Task<LeaveAllocation> GetUserAllocation(string userId,int leaveTypeId);


    }
}