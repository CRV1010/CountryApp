﻿using HR.LeaveManagement.Application.Contracts.Persistence;
using HR.LeaveManagement.Domain;
using HR.LeaveManagement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;

namespace HR.LeaveManagement.Persistence.Repository
{
    public class LeaveAllocationRepository : GenericRepository<LeaveAllocation>, ILeaveAllocationRepository
    {
        public LeaveAllocationRepository(HRDbContext dbContext) : base(dbContext)
        {
        }

        public async Task AddAllocation(List<LeaveAllocation> allocation)
        {
            await dbContext.AddRangeAsync(allocation);
        }

        public async Task<bool> AllocaitonExist(string userId, int leaveTypeId, int period)
        {
            return await dbContext.LeaveAllocations.AnyAsync(q=>q.EmployeeId==userId
            && q.LeaveTypeId==leaveTypeId && q.Period==period);
        }

        public async Task<LeaveAllocation> GetLeaveAllocationWithDetails(int id)
        {
            var leaveAllocations = await dbContext.LeaveAllocations
                .Include(q => q.LeaveType)
                .ToListAsync();
            return leaveAllocations;
        }

        public Task<List<LeaveAllocation>> GetLeaveAllocationWithDetails()
        {
            throw new NotImplementedException();
        }

        public Task<List<LeaveAllocation>> GetLeaveAllocationWithDetails(string userId)
        {
            throw new NotImplementedException();
        }

        public Task<LeaveAllocation> GetUserAllocation(string userId, int leaveTypeId)
        {
            throw new NotImplementedException();
        }
    }
}
