﻿using HR.LeaveManagement.Application.Contracts.Persistence;
using HR.LeaveManagement.Domain.Common;
using HR.LeaveManagement.Persistence.DatabaseContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR.LeaveManagement.Persistence.Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : BaseEntity 
    {
        protected readonly HRDbContext dbContext;

        public GenericRepository(HRDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<T> CreateAsync(T entity)
        {
            await dbContext.AddAsync(entity);
            await dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<T> DeleteAsync(T entity)
        {
            dbContext.Remove(entity);
            await dbContext.SaveChangesAsync();
            return entity;
        }

        public async Task<List<T>> GetAsync()
        {
            return await dbContext.Set<T>().AsNoTracking().ToListAsync();
        }

        public async Task<T> GetByIdAsync(int id)
        {
            return await dbContext.Set<T>().AsNoTracking().FirstOrDefaultAsync(t=>t.Id==id);
        }

        public async Task<T> UpdateAsync(T entity)
        {
           // dbContext.Update(entity); // It Updates the Whole object and required 
                          // full sql statement and updation of each field take place


            dbContext.Entry(entity).State = EntityState.Modified; // By using this we set
                                // entityState in modification so only changes are updated

            await dbContext.SaveChangesAsync();
            return entity;
        }
    }
}
