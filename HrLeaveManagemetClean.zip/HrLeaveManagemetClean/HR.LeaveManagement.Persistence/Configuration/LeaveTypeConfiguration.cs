﻿using HR.LeaveManagement.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace HR.LeaveManagement.Persistence.Configuration
{
    public class LeaveTypeConfiguration : IEntityTypeConfiguration<LeaveType>
    {
        public void Configure(EntityTypeBuilder<LeaveType> builder)
        {
            var leavesData = new List<LeaveType>
            {
                new LeaveType
                {
                    Id= 1,
                    Name = "Vacation",
                    DefaultDays = 10,
                    DateCreated = DateTime.Now,
                    DateModified = DateTime.Now
                },
                new LeaveType
                {
                    Id= 2,
                    Name = "Emergency",
                    DefaultDays = 3,
                    DateCreated = DateTime.Now,
                    DateModified = DateTime.Now
                },
            };


            builder.HasData(leavesData);

        }
    }
}
